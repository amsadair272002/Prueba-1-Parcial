package com.example.calculadorasencilla;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button btnSuma;
    private Button btnResta;
    private Button btnMultiplicacion;
    private Button btnDivision;
    private TextView txtRespuesta;
    private EditText txtNumero1;
    private EditText txtNumero2;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSuma=findViewById(R.id.btnSuma);
        btnSuma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtRespuesta.setText(suma(Integer.parseInt(txtNumero1.getText().toString()), Integer.parseInt(txtNumero2.getText().toString())) + "");
            }
        });


        btnResta= findViewById(R.id.btnResta);
        btnResta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtRespuesta.setText(resta(Integer.parseInt(txtNumero1.getText().toString()), Integer.parseInt(txtNumero2.getText().toString())) + "");
            }
        });



        btnMultiplicacion= findViewById(R.id.btn_multiplicacion);
        btnMultiplicacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtRespuesta.setText(multplicacion(Integer.parseInt(txtNumero1.getText().toString()), Integer.parseInt(txtNumero2.getText().toString())) + "");
            }
        });


        btnDivision = findViewById(R.id.btnDivision);
        btnDivision.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtRespuesta.setText(division(Integer.parseInt(txtNumero1.getText().toString()), Integer.parseInt(txtNumero2.getText().toString())) + "");
            }
        });


        txtRespuesta = findViewById(R.id.txtRespuesta);

        txtNumero1 = findViewById(R.id.txtNumero1);
        txtNumero2= findViewById(R.id.txtNumero2);


    }
    public double suma (int a , int b){
        return a+b;
    }

    public double resta (int a , int b){
        return a-b;

    }

    public double multplicacion (int a , int b){
        return a*b;
    }

    public float division (int a , int b){
        int respuesta=0;
        if (b!=0){
            respuesta = a/b;
        }
        return respuesta;

    }

}